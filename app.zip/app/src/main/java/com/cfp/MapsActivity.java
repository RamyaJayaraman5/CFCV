package com.cfp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

public class MapsActivity extends AppCompatActivity  {

    private static DecimalFormat df = new DecimalFormat("0.0000");

    private GPSTracker gpsTracker;
    private Location mLocation;
    private static final String TAG = "OSRMActivity";
    private static final String mode = "car";
    double latitude, longitude;
    double dlat, dlng;
    private float carTime, carDist;

   public TextView currlatlong;
   public EditText txtCurrentaddress;
   public TextView Destlatlong;
   public EditText txtDestination;
   public CardView cardCar;
   public TextView txtCarDistance;
   public TextView txtCarDuration;
   public CardView cardTrain;
   public TextView txtTrainDistance;
   public TextView txtTrainDuration;
   public CardView cardBus;
   public TextView txtBusDistance;
   public TextView txtBusDuration;
   public CardView cardChart;
   public TextView textView3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_1);
        try {
            gpsTracker = new GPSTracker(getApplicationContext());
            mLocation = gpsTracker.getLocation();
            Init();
            Controllisteners();
            latitude = mLocation.getLatitude();
            longitude = mLocation.getLongitude();
            loadCurrentAddress();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadCurrentAddress() {
        df.setRoundingMode(RoundingMode.DOWN);
        txtCurrentaddress.setText(getLocationAddress(latitude, longitude));
    }

    private void Controllisteners() {

        cardChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getChart();
            }
        });

        txtDestination.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (txtDestination.getRight() - txtDestination.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        // your action here
                        try {
                            getDestinationLocPoints();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return true;
                    }
                }
                return false;
            }
        });

    }

    private void Init() {
        currlatlong = findViewById( R.id.currlatlong );
        txtCurrentaddress = findViewById( R.id.txt_currentaddress);
        Destlatlong = findViewById( R.id.Destlatlong );
        txtDestination = findViewById( R.id.txt_destination );
        cardCar = findViewById( R.id.card_car );
        txtCarDistance = findViewById( R.id.txt_car_distance );
        txtCarDuration = findViewById( R.id.txt_car_duration );
        cardTrain = findViewById( R.id.card_train );
        txtTrainDistance = findViewById( R.id.txt_train_distance );
        txtTrainDuration = findViewById( R.id.txt_train_duration );
        cardBus = findViewById( R.id.card_bus );
        txtBusDistance = findViewById( R.id.txt_bus_distance );
        txtBusDuration = findViewById( R.id.txt_bus_duration );
        cardChart = findViewById( R.id.card_chart );
        textView3 = findViewById( R.id.textView3 );

    }


    private String getLocationAddress(double latitude, double longitude) {
        String address="N/A";
        try {
            Geocoder gc = new Geocoder(this);
            List<Address> list =  gc.getFromLocation(latitude, longitude, 1);
            Address addressstr = list.get(0);
            address=addressstr.getAddressLine(0) ;
            //+ ", " + addressstr.getLocality()
        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;
    }

    public void getDestinationLocPoints() throws IOException {//on clickdestination

        Geocoder gc = new Geocoder(this);
        List<Address> list = gc.getFromLocationName(txtDestination.getText().toString(), 1);
        Address address = list.get(0);
        String locality = address.getLocality();
        String addressStr=address.getAddressLine(0) ;
        //+ ", " + address.getLocality()
      //  Toast.makeText(this, locality, Toast.LENGTH_LONG).show();
        dlat = address.getLatitude();
        dlng = address.getLongitude();
        //Destlatlong.setTextColor(Color.RED);
        //round off to 4 decimal places
        df.setRoundingMode(RoundingMode.UP);
        //Destlatlong.setText("Destination Location - Latitude:" + Math.round(dlat * 10000.0) / 10000.0 + ",Longitude:" + Math.round(dlng * 10000.0) / 10000.0);
        txtDestination.setText(getLocationAddress(dlat, dlng));
       // goToLocationZoom(dlat, dlng, 15);

        getDistanceandTime();
    }

    double common_distance=0;
    public void getChart() {
        Intent intent = new Intent(this, ChartActivity.class);
        //first element:distance in Kms, second element: time in mins
        double[] train = new double[]{ common_distance, 190};
        double[] bus = new double[]{ common_distance, 160};
        double[] car = new double[]{carDist, carTime};
        intent.putExtra("car", car);
        intent.putExtra("bus", bus);
        intent.putExtra("train", train);
        startActivity(intent);
    }

    //get distance duration for car
    public void getDistanceandTime() throws IOException {
        try {

            //car calculation
            carCalculation(latitude, longitude, dlat, dlng, mode);

            //other calculation
            double distanceinkm=calculateHaversine(latitude, longitude, dlat, dlng);
            NumberFormat formatter = new DecimalFormat("#0.00");
            String value=(formatter.format(distanceinkm))+" Km";
            txtTrainDistance.setText(value);

            txtBusDistance.setText(value);
            common_distance=Double.parseDouble(formatter.format(distanceinkm));
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    void carCalculation(double srcLat, double srcLng, double destLat, double destLng, String mode) throws IOException {

        StringBuilder strUrl = new StringBuilder();
        String url = "http://router.project-osrm.org/route/v1/";//car/14.2825455,48.2897534;14.319305,48.336614";
        strUrl.append(url);
        strUrl.append(mode + "/");
        strUrl.append(srcLng + ",");
        strUrl.append(srcLat + ";");
        strUrl.append(destLng + ",");
        strUrl.append(destLat + "");

        Log.e("carCalculation: url", strUrl.toString());

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(strUrl.toString())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                call.cancel();
                Log.d(TAG.concat(e.getMessage()), "exception");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {

                    final String myResponse = response.body().string();

                    MapsActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //JSON RESPONSE

                            Log.d(TAG.concat(myResponse), "success");
                            try {
                                JSONObject jObj = new JSONObject(myResponse);
                                JSONArray arr = jObj.getJSONArray("routes");
                                JSONObject json = arr.getJSONObject(0);
                                Double Duration = json.getDouble("duration") / 60;
                                Double Distance = json.getDouble("distance") / 1000;
                                carTime = Float.parseFloat(Duration.toString());
                                carDist = Float.parseFloat(Distance.toString());
                                //car distance and time
                                txtCarDistance.setText(String.valueOf(Math.round(Distance * 10000.0) / 10000.0)+" Km");
                                txtCarDuration.setText(String.valueOf(Math.round(Duration * 10000.0) / 10000.0)+" Minutes");

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                }
            }
        });

    }

    public double calculateHaversine(double userLat, double userLng, double destLat, double destLng)
    {
        final int R = 6371; // Radious of the earth
        Double lat1 = userLat;
        Double lon1 = userLng;
        Double lat2 = destLat;
        Double lon2 = destLng;
        Double latDistance = toRad(lat2-lat1);
        Double lonDistance = toRad(lon2-lon1);
        Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
                        Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        Double distance = R * c;
        return distance;
    }
    private static Double toRad(Double value) {
        return value * Math.PI / 180;
    }


}