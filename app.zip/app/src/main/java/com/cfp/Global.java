package com.cfp;

public class Global {

    public static String BUNDLE_SOURCELATITUDE="SOURCELATITUDE";
    public static String BUNDLE_SOURCELONGITUDE="SOURCELONGITUDE";
    public static String BUNDLE_DESTLATITUDE="DESTLATITUDE";
    public static String BUNDLE_DESTLONGITUDE="DESTLONGITUDE";
    public static String BUNDLE_MODE="MODE";

}
