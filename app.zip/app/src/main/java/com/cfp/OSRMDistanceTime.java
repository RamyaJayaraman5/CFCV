package com.cfp;

import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class OSRMDistanceTime extends AppCompatActivity {
    OkHttpClient client = new OkHttpClient();
    TextView txtString;
    TextView distance;
    TextView duration;
    //uribuilder
    //Uri.Builder builder = new Uri.Builder()
    // builder.scheme("https")
    //.authority("www.myawesomesite.com")
    // .appendPath("turtles")
    //  .appendPath("types")
    //  .appendQueryParameter("type", "1")
    //   .appendQueryParameter("sort", "relevance")
    //  .fragment("section-name");
    // String myUrl = builder.build().toString();
//    public String url = "http://router.project-osrm.org/route/v1/car/14.2825455,48.2897534;14.319305,48.336614";
    private static final String TAG = "OSRMActivity";
    //random urlfor testing
    // https://reqres.in/api/users?page=2
    // http://router.project-osrm.org/route/v1/driving/13.388860,52.517037;13.397634,52.529407;13.428555,52.523219?overview=false

    //jku and froschberg
    //http://router.project-osrm.org/route/v1/driving/14.2824,48.2898;14.3193,48.3366.json?overview=false";
    //http://router.project-osrm.org/route/v1/car/14.2825455,48.2897534;14.319305,48.336614

    // format
    // GET /route/v1/{profile}/{coordinates}?alternatives={true|false|number}&steps={true|false}&geometries={polyline|polyline6|geojson}&overview={full|simplified|false}&annotations={true|false}
    ///{service}/{version}/{profile}/{coordinates}[.{format}]?option=value&option=value
    //table
    //GET /table/v1/{profile}/{coordinates}?{sources}=[{elem}...];&{destinations}=[{elem}...]&annotations={duration|distance|duration,distance}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_osrmdistance_time);
        txtString = (TextView) findViewById(R.id.txtString);
        distance = (TextView) findViewById(R.id.distance);
        duration = (TextView) findViewById(R.id.duration);

        try {

            //here u can get the bundles passing from the previous intent then pass it to the run method
            Bundle b = new Bundle();
            b = getIntent().getExtras();
            double srcLat = b.getDouble(Global.BUNDLE_SOURCELATITUDE);//same here too da
            double srcLng = b.getDouble(Global.BUNDLE_SOURCELONGITUDE);//same here too da
            double destLat = b.getDouble(Global.BUNDLE_DESTLATITUDE);//same here too da
            double destLng = b.getDouble(Global.BUNDLE_DESTLONGITUDE);//same here too da
            String mode = b.getString(Global.BUNDLE_MODE);//same here too da //mode not from bundleight


            run(srcLat, srcLng, destLat, destLng, mode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void run(double srcLat, double srcLng, double destLat, double destLng, String mode) throws IOException {

        StringBuilder strUrl = new StringBuilder();
        String url = "http://router.project-osrm.org/route/v1/";//car/14.2825455,48.2897534;14.319305,48.336614";
        strUrl.append(url);
        strUrl.append(mode + "/");
        strUrl.append(srcLng + ",");
        strUrl.append(srcLat + ";");
        strUrl.append(destLng + ",");
        strUrl.append(destLat + "");

        Log.e("run: url", strUrl.toString());

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(strUrl.toString())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                call.cancel();
                Log.d(TAG.concat(e.getMessage()), "exception");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {

                    final String myResponse = response.body().string();

                    OSRMDistanceTime.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //JSON RESPONSE
                            // txtString.setText(myResponse);
                            Log.d(TAG.concat(myResponse), "success");
                            try {
                                JSONObject jObj = new JSONObject(myResponse);
                                JSONArray arr = jObj.getJSONArray("routes");
                                JSONObject json = arr.getJSONObject(0);
                                Double Duration = json.getDouble("duration") / 60;
                                Double Distance = json.getDouble("distance") / 1000;

                                distance.setTextColor(Color.BLUE);
                                distance.setText("Distance in Km" + " " + Distance.toString());
                                duration.setTextColor(Color.MAGENTA);
                                duration.setText("Duration in minutes" + " " + Duration.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                }
            }
        });
    }
}