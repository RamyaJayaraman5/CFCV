package com.cfp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.LargeValueFormatter;

import java.util.ArrayList;

public class ChartActivity extends AppCompatActivity {
    //grams of CO2 emissions per person per kilometer
    public static final float CAR_CO2_FACTOR = 0.171f;
    public static final float BUS_CO2_FACTOR = 0.027f;
    public static final float TRAIN_CO2_FACTOR = 0.006f;

    Double minTravelTime;
    int minTravelTimeIndex;
    Double minEmissions;
    int minEmissionsIndex;
    Double maxValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        TextView emissionTV =  findViewById(R.id.carbonEmission);
        TextView travelTimeTV =  findViewById(R.id.travelTime);


        Bundle stats = getIntent().getExtras();
        double[] carStats = stats.getDoubleArray("car");
        double[] busStats = stats.getDoubleArray("bus");
        double[] trainStats = stats.getDoubleArray("train");

        ArrayList<Double> distances = new ArrayList<>();
        ArrayList<Double> times = new ArrayList<>();
        ArrayList<Double> emissions = new ArrayList<>();

        ArrayList<String> transportOptions = new ArrayList<>();
        transportOptions.add("Car");
        transportOptions.add("Bus");
        transportOptions.add("Train");

        distances.add(carStats[0]);
        distances.add(busStats[0]);
        distances.add(trainStats[0]);
        times.add(carStats[1]);
        times.add(busStats[1]);
        times.add(trainStats[1]);
        emissions.add(carStats[0]*CAR_CO2_FACTOR);
        emissions.add(busStats[0]*BUS_CO2_FACTOR);
        emissions.add(trainStats[0]*TRAIN_CO2_FACTOR);

        HorizontalBarChart chart = findViewById(R.id.barchart);

        float barWidth =0.25f;
        float barSpace=0f;
        float groupSpace=0.3f;
        chart.setDescription(null);
        chart.setPinchZoom(false);
        chart.setScaleEnabled(false);
        chart.setDrawBarShadow(false);
        chart.setDrawGridBackground(false);
        int groupCount = 3;

        ArrayList xVals = new ArrayList();

        xVals.add("");
        xVals.add("");
        xVals.add("");

        ArrayList distancePoints = new ArrayList();
        ArrayList timePoints = new ArrayList();
        ArrayList emissionPoints = new ArrayList();

        minTravelTime = times.get(0);
        minEmissions = emissions.get(0);
        maxValue = distances.get(0);

        for(int i=0; i<3; i++){
            distancePoints.add(new BarEntry((float)i+1, distances.get(i).floatValue()));
            timePoints.add(new BarEntry((float)i+1, times.get(i).floatValue()));
            emissionPoints.add(new BarEntry((float)i+1, emissions.get(i).floatValue()));

            if(times.get(i)<minTravelTime){
                minTravelTime = times.get(i);
                minTravelTimeIndex = i;
            }
            if(emissions.get(i)<minEmissions){
                minEmissions= emissions.get(i);
                minEmissionsIndex = i;
            }

            if(maxValue<distances.get(i)){
                maxValue = distances.get(i);
            }
            if(maxValue<times.get(i)){
                maxValue = times.get(i);
            }
            if(maxValue<emissions.get(i)){
                maxValue = emissions.get(i);
            }
        }

        emissionTV.setText(emissionTV.getText() + " " + transportOptions.get(minEmissionsIndex));
        travelTimeTV.setText(travelTimeTV.getText() + " " + transportOptions.get(minTravelTimeIndex));

     /*distancePoints.add(new BarEntry(1, carStats[0]));
     timePoints.add(new BarEntry(1, carStats[1]));
     emissionPoints.add(new BarEntry(1, 3f));
     distancePoints.add(new BarEntry(2, busStats[0]));
     timePoints.add(new BarEntry(2, busStats[1]));
     emissionPoints.add(new BarEntry(2, 6f));
     distancePoints.add(new BarEntry(3, trainStats[0]));
     timePoints.add(new BarEntry(3, trainStats[1]));
     emissionPoints.add(new BarEntry(3, 1.5f));*/

        BarDataSet distanceSeries, timeSeries, emissionSeries;
        distanceSeries = new BarDataSet(distancePoints, "Distance in Km.");
        distanceSeries.setColor(Color.GREEN);
        timeSeries = new BarDataSet(timePoints, "Time in min.");
        timeSeries.setColor(Color.BLUE);
        emissionSeries = new BarDataSet(emissionPoints, "Co2 in Kg.");
        emissionSeries.setColor(Color.RED);
        BarData data = new BarData(distanceSeries, timeSeries, emissionSeries);
        data.setValueFormatter(new LargeValueFormatter());

        data.setDrawValues(false);

        chart.setData(data);
        chart.getBarData().setBarWidth(barWidth);
        chart.groupBars(0f, groupSpace, barSpace);
        chart.getData().setHighlightEnabled(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setGranularity(0f);
        xAxis.setGranularityEnabled(true);
        xAxis.setCenterAxisLabels(true);
        xAxis.setDrawGridLines(false);
        xAxis.setAxisMinimum(0f);
        xAxis.setAxisMaximum(3);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xVals));
        xAxis.setDrawLabels(true);

//Y-axis
        chart.getAxisLeft().setEnabled(false);
        YAxis axisRight = chart.getAxisRight();
        axisRight.setValueFormatter(new LargeValueFormatter());
        axisRight.setDrawGridLines(true);
        axisRight.setSpaceTop(35f);
        // axisRight.setAxisMinimum(0f);
        axisRight.setAxisMaximum(maxValue.floatValue() + (maxValue.floatValue() * 0.05f));
        axisRight.setDrawLabels(true);

        Legend l = chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);

        ArrayList<Bitmap> imageList = new ArrayList<>();
        imageList.add(BitmapFactory.decodeResource(getResources(), R.drawable.car));
        imageList.add(BitmapFactory.decodeResource(getResources(), R.drawable.bus));
        imageList.add(BitmapFactory.decodeResource(getResources(), R.drawable.train));
        chart.setRenderer(new BarChartCustomRenderer(chart, chart.getAnimator(), chart.getViewPortHandler(), imageList, this));
        chart.setExtraOffsets(20, 0, 0, 20);
        //chart.invalidate();


    }
}
